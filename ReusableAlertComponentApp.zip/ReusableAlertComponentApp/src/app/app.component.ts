﻿import { Component } from '@angular/core';
import { AlertService } from './_alert';
@Component({ selector: 'app', templateUrl: 'app.component.html' })
export class AppComponent { 
    options = {
        autoClose: false,
        keepAfterRouteChange: false
    };
    constructor(public alertService: AlertService) { }
}